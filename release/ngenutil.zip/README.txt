﻿ngenutil
========

Ngen Utility

.NET Framework に付属するネイティブイメージジェネレーター(Ngen.exe)をGUIにしたものです。

https://sites.google.com/site/zirrusc/app/ngenutil

https://twitter.com/zirrusc


* アプリケーションの名前 : Ngen Utility
* アセンブリ名 : ngenutil.exe
* 著作 : zirrusc
* ライセンス : GPL v3
* 言語 : 日本語、英語 (Japanese, English)
* バージョン : 1
* プラットフォーム : Windows Vista以上
* 必要なソフト : .NET Framework 4.0以上 (Client Profileでも可)
* 特記 : ngenutil.exeを起動するためには管理者特権が必要です。
  ngen.exeが管理者特権が必要なためです。
